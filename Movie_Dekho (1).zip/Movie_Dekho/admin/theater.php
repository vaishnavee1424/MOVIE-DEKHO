<?php
include('../connect.php');
if(!isset($_SESSION['uid'])){
    echo "<script> window.location.href='../login.php';</script>";
}
?>
<html>
  <head>
    <title>Theater</title>
</head>
    <body>
    <?php include('header.php') ?>
    <?php
    if(isset($_GET['editid'])){
       
        $catid = $_GET['editid'];
    $sql ="SELECT * FROM `categories` WHERE catid = 'editid'";
    $res= mysqli_query($con,$sql);
    $editdata= mysqli_fetch_array($res);
    
?>
<?php
}else{
?>
<div class="container">
        <div class="row">
            <div class="col-lg-6">
<form action="theater.php" method="post" enctype="multipart/form-data"> 
                <div class="form-group mb-4">
                  <select name="movieid" class="form-control">
                    <option value="">Select Movies</option>
                    <?php
                    $sql = "SELECT * FROM `movies`";
$res = mysqli_query($con,$sql);
if(mysqli_num_rows($res)>0){
    while($data = mysqli_fetch_array($res)){
      ?> <option value="<?=$data['movieid']?>"><?=$data['title']?></option><?php
    }
  }else{
    ?> <option value="">No Category Found</option> <?php
  } ?> 
      </select>
<input type="time" class="form-control" value="" name="timing">
</div>
<div class="form-group mb-4">
<input type="text" class="form-control" value="" name="days" placeholder="Enter days">
</div>
<div class="form-group mb-4">
<input type="date" class="form-control" value="" name="date">
</div>
<div class="form-group mb-4">
<input type="number" class="form-control" value="" name="price"  placeholder="enter price">
</div>
<div class="form-group mb-4">
<input type="text" class="form-control" value="" name="location"  placeholder="enter location">
</div>

<div class="form-group mb-4">
<input type="submit" class="btn btn-primary" value="Add Theater" name="add">
</div>
</form>

<?php
}
?>
</div>
    <div class="col-lg-6">
        <table class="table">
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Category</th>
                <th>Poster</th>
                <th>Action</th>
</tr>
<?php
$sql = "SELECT movies.*,categories.catname
from movies 
inner join categories on categories.catid = movies.catid";
$res = mysqli_query($con,$sql);
if(mysqli_num_rows($res)>0){
    while($data = mysqli_fetch_array($res)){
        ?>
        <tr>
        <td><?=$data['movieid']?></td>
        <td><?=$data['title']?></td>
        <td><?=$data['catname']?></td>
        <td><img src="uploads/<?=$data['image']?>" height="50" width="50"alt=""></td>
        <td><a href="movies.php?editid=<?= $data['catid'] ?>" class="btn btn-primary">Edit</a>
        <td><a href="movies.php?deleteid=<?= $data['movieid'] ?>" class="btn btn-danger">Delete</a></td>
    </td>
        </tr>
        <?php
}
}else{
    echo "no record found";
}
?>
</table>
</div>
</div>
<?php include('footer.php') ?>
</body>

    </html>
   <?php
    if(isset($_POST['add'])){
        $catid = $_POST['movieid'];
        $days = $_POST['days'];
        $timing = $_POST['timing'];
        $price = $_POST['price'];
        $date = $_POST['date'];
        $location = $_POST['location'];
       

      $sql = "INSERT INTO `theater`(`timing`, `days`, `date`, `price`,`movieid`,`location`) 
      VALUES ('$timing','$days','$date','$price','$movieid','$location')";
      if(mysqli_query($con,$sql)){
        echo "<script> alert('theater added')</script>";
        echo "<script> window.location.href='theater.php' </script>";
      }else{
        echo "<script> alert('not added')</script>";
      }
if($isset($_POST['update'])){
    $name = $_POST['catname'];
        $catid = $_POST['catid'];
        $sql = "UPDATE `categories` SET `catname`='$catname' WHERE catid = '$catid'";
        if(mysqli_query($con,$sql)){
          echo "<script> alert('category update')</script>";
          echo "<script> window.location.href='categories.php' </script>";
        }else{
          echo "<script> alert('not updated')</script>";
        }
          

}
if($isset($_GET['deleteid'])){
    echo $deleteid = $GET_['deleteid'];
    $sql = "DELETE FROM `categories` WHERE catiid ='$deleteid'";
if(mysqli_query($con,$sql)){
    echo "<script> alert('category deleted)</script>";
    echo "<script> window.location.href='categories.php'</script>";
  }else{
    echo "<script> alert('not')</script>";
  }
}
}
?>
    
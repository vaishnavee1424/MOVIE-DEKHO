<?php
session_start();
//unset_session($_SESSION['uid']);
session_destroy();
echo "<script> window.location.href='../login.php';</script>";
?>
<?php include('../connect.php');
if(!isset($_SESSION['uid'])){
    echo "<script> window.location.href='../login.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dashboard</title>
</head>
<body>

<?php include('header.php') ?>
<h1>Welcome to Admin Page</h1>
<?php include('footer.php') ?> 
</body>
</html>
